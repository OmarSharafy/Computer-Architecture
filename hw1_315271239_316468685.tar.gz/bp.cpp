#include <iostream>
#include <vector>
#include "bp_api.h"
#include <cmath>
#define target_size 30
#define fsm_size 256

enum FSM_STATE {SNT = 0, WNT = 1 , WT = 2 , ST = 3};

void Update_index(int fsm[],bool taken,int index)
{
    if (taken)
    {
        if (fsm[index]<3)
        {
            fsm[index]++;
        }
    }
    else
    if (fsm[index]>0)
    {
        fsm[index]--;
    }
}

int Update_History(int History,bool taken,int HistorySize)
{
    uint32_t mask = 0;
    for (int i = 0; i < HistorySize; i++) {
        mask = mask << 1;
        mask += 1;
    }
    int temp = History;
    temp*=2;
    if(taken)
    {
        temp++;
    }
    History= (temp & (mask));
    return History;
}


unsigned int GetIndex ( uint32_t pc, int num_of_bits)
{
    uint32_t mask = 0;
    for (int i = 0; i < num_of_bits; i++) {
        mask = mask << 1;
        mask += 1;
    }
    return (pc>>2 & (mask));
}

uint32_t RealTag( uint32_t pc, int num_of_bits,int log2btbsize)
{
    uint32_t mask = 0;
    for (int i = 0; i < num_of_bits; i++) {
        mask = mask << 1;
        mask += 1;
    }
    return (pc >> (2+log2btbsize) & (mask));
}



int L_Shared(int Hisroty,uint32_t pc , int share,int historysize){
    uint32_t mask = pow(2,historysize);
    mask--;
    int temp=((pc>>2) & mask);
    if (share==1)
    {
        return (Hisroty ^ temp);
    }
    else if (share==2)
    {
        int temp=((pc>>16) & mask);
        temp=temp ^ Hisroty;
        return (temp);
    }
    else return Hisroty;
}

class BtB_Line
{
private:

public:
    uint32_t tag;
    uint32_t target;
    bool isGlobalHist;
    bool isGlobalTable;
    int History_size;
    int original_state;
    int History=0;
    int fsm_table[fsm_size];
    BtB_Line(uint32_t tag, uint32_t target, bool isGlobalHist, bool isGlobalTable, int historySize, int originalState)
            : tag(tag), target(target), isGlobalHist(isGlobalHist), isGlobalTable(isGlobalTable),
              History_size(historySize), original_state(originalState) {
        if (!isGlobalTable) {
            int fsm_Size = pow(2, History_size);
            for (int i = 0; i < fsm_Size; ++i) {
                fsm_table[i]=original_state;
            }
        }
    }
    virtual ~BtB_Line()
    = default;

};



class Branch_predictor {
private:

public:
    unsigned btbSize;
    unsigned historySize;
    unsigned tagSize;
    unsigned fsmState;
    bool isGlobalHist;
    bool isGlobalTable;
    int share;
    int branch_calls;
    int flushes;
    int* fsm_table;
    bool* ValidBit;
    std::vector<BtB_Line> BTB;
    int GlobalHistory=0;

    /**
    * @brief Construct a new BP object
    * @param btbSize - The number of rows in the BTB.
    * @param tagSize - The number of tag bits.
    * @param historySize - The number of history bits.
    * @param fsmState - The initial fsm state.
    * @param isGlobalHist - BTB use global History or not.
    * @param isGlobalTable - BTB use global Table or not.
    * @param share - 0/1/2 - BTB type of share indexing - no share, lsb_share , mid_share.
    */

    Branch_predictor(unsigned int btbSize, unsigned int historySize, unsigned int tagSize, unsigned int fsmState,
                     bool isGlobalHist, bool isGlobalTable, int share) : btbSize(btbSize), historySize(historySize),
                     tagSize(tagSize), fsmState(fsmState),isGlobalHist(isGlobalHist),
                     isGlobalTable(isGlobalTable), share(share) {
        branch_calls=0;
        flushes=0;
        int fsm_Size = pow(2, historySize);
        for (unsigned int i = 0; i < btbSize; ++i) {
            BtB_Line* temp= new BtB_Line(-1,0, false, false,historySize,fsmState);
            BTB.push_back(*temp);
        }

        ValidBit = new bool[btbSize];
        for (unsigned int i = 0; i < btbSize; ++i) {
            ValidBit[i]= false;
        }

        if (isGlobalTable) {

            fsm_table = new int[fsm_Size];
            for (int i = 0; i < fsm_Size; ++i) {
                fsm_table[i] = fsmState;
            }
        }

    }

    virtual ~Branch_predictor() {}

};

Branch_predictor* bp = nullptr;

int BP_init(unsigned btbSize, unsigned historySize, unsigned tagSize, unsigned fsmState,
            bool isGlobalHist, bool isGlobalTable, int Shared){
    bp =
            new Branch_predictor(btbSize,historySize,tagSize,fsmState,isGlobalHist,isGlobalTable,Shared);
    if(bp == nullptr)
    {
        return -1;
    }

    return 0;
}

bool BP_predict(uint32_t pc, uint32_t *dst) {

    unsigned int index = GetIndex(pc, log2(bp->btbSize));
    uint32_t tag = RealTag(pc, bp->tagSize, log2(bp->btbSize));

    if (index ==22)
    {
        printf("hi");
    }

    if (bp->BTB[index].tag == tag && bp->ValidBit[index]) {
        if (!bp->isGlobalHist && !bp->isGlobalTable) {
            if (((bp->BTB[index].fsm_table)[L_Shared(bp->BTB[index].History, pc, bp->share,bp->historySize)]) > 1) {
                *dst = bp->BTB[index].target;
                return true;
            } else {
                *dst = pc + 4;
                return false; //thats not the real tag we lack some things
            }
        }
        else if (bp->isGlobalHist && !bp->isGlobalTable) {
            if (((bp->BTB[index].fsm_table)[L_Shared(bp->GlobalHistory, pc, bp->share,bp->historySize)]) > 1) {
                *dst = bp->BTB[index].target;
                return true;
            } else {
                *dst = pc + 4;
                return false; //thats not the real tag we lack some things
            }
        }
        else if (!bp->isGlobalHist && bp->isGlobalTable) {
            if (bp->fsm_table[L_Shared(bp->BTB[index].History, pc, bp->share,bp->historySize)] > 1) {
                *dst = bp->BTB[index].target;
                return true;
            } else {
                *dst = pc + 4;
                return false; //thats not the real tag we lack some things
            }
        }
        else if (bp->isGlobalHist && bp->isGlobalTable) {
            if (bp->fsm_table[L_Shared(bp->GlobalHistory, pc, bp->share,bp->historySize)] > 1) {
                *dst = bp->BTB[index].target;
                return true;
            }
            else {
                *dst = pc + 4;
                return false; //thats not the real tag we lack some things
            }
        }
    }


    if ( bp->BTB[index].tag != tag   && bp->ValidBit[index]) {
        bp->ValidBit[index]= false;
        bp->BTB[index].History = 0;
        int fsm_Size = pow(2, bp->BTB[index].History_size);
        for (int i = 0; i < fsm_Size; ++i) {
            bp->BTB[index].fsm_table[i] = bp->BTB[index].original_state;
        }
        bp->BTB[index].tag = tag;
    }
    *dst = pc + 4;
    return false; //thats not the real tag we lack some things
}


void BP_update(uint32_t pc, uint32_t targetPc, bool taken, uint32_t pred_dst){

    uint32_t dst = 0;
    uint32_t Realtag = RealTag(pc, bp->tagSize,log2(bp->btbSize));
    bool Is_taken = BP_predict(pc, &dst);
    unsigned int index = GetIndex(pc, log2(bp->btbSize));
    bp->branch_calls++;
    if (Is_taken!=taken )
    {
        bp->flushes++;
    }
    else if (Is_taken==taken)
    {
        if (!taken && pred_dst != pc + 4)
        {
            bp->flushes++;
        }
        if (taken && pred_dst!= targetPc)
        {
            bp->flushes++;
        }


    }
    if (!bp->ValidBit[index])
    {
        bp->ValidBit[index]= true;
        bp->BTB[index].tag=Realtag;
    }
     bp->BTB[index].target=targetPc;
        if (bp->isGlobalHist && bp->isGlobalTable)
        {
            Update_index(bp->fsm_table,taken, L_Shared(bp->GlobalHistory,pc,bp->share,bp->historySize));
            bp->GlobalHistory= Update_History(bp->GlobalHistory,taken,bp->historySize);
        }
        else  if (!bp->isGlobalHist && bp->isGlobalTable)
        {
            Update_index(bp->fsm_table,taken, L_Shared(bp->BTB[index].History,pc,bp->share,bp->historySize));
            bp->BTB[index].History = Update_History(bp->BTB[index].History,taken,bp->historySize);
        }
        else  if (bp->isGlobalHist && !bp->isGlobalTable)
        {
            Update_index(bp->BTB[index].fsm_table,taken, L_Shared(bp->GlobalHistory,pc,bp->share,bp->historySize));
            bp->GlobalHistory= Update_History(bp->GlobalHistory,taken,bp->historySize);
        }
        else {
            Update_index(bp->BTB[index].fsm_table,taken, L_Shared(bp->BTB[index].History,pc,bp->share,bp->historySize));
            bp->BTB[index].History = Update_History(bp->BTB[index].History,taken,bp->historySize);
        }
}

void BP_GetStats(SIM_stats *curStats){
    curStats->br_num=bp->branch_calls;
    curStats->flush_num=bp->flushes;

    if (bp->isGlobalHist && bp->isGlobalTable)
    {
        curStats->size=(bp->btbSize)*(1+bp->tagSize+target_size)+2* pow(2,bp->historySize)+bp->historySize;
    }
    else  if (!bp->isGlobalHist && bp->isGlobalTable)
    {
        curStats->size=(bp->btbSize)*(1+bp->tagSize+target_size+bp->historySize)+2* pow(2,bp->historySize);
    }
    else  if (bp->isGlobalHist && !bp->isGlobalTable)
    {
        curStats->size=(bp->btbSize)*(1+bp->tagSize+target_size+2* pow(2,bp->historySize))+bp->historySize;
    }
    else {
           curStats->size=(bp->btbSize)*(1+bp->tagSize+target_size+bp->historySize+2* pow(2,bp->historySize));
    }

}

/* 046267 Computer Architecture - Winter 20/21 - HW #2 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <cstdint>

unsigned get_mask_with_pow(int num_of_bits)
{
    num_of_bits = pow(2, num_of_bits);
    unsigned mask = 0;
    for (int i = 0; i < num_of_bits; i++)
    {
        mask = mask << 1;
        mask += 1;
    }
    return mask;
}

unsigned get_mask(int num_of_bits)
{
    unsigned mask = 0;
    for (int i = 0; i < num_of_bits; i++)
    {
        mask = mask << 1;
        mask += 1;
    }
    return mask;
}


int time_cache = 1; /// for LRU

class Line {
public:
    unsigned address = 0;
    unsigned tag = -1;
    bool dirty = false;
    unsigned lastCall = 0;
    Line() {}

    virtual ~Line() {}
};


class Level {
public:
    int L_Size;
    int BlockSize;
    int L_Cycle;
    int WrAllocte;
    int ways;
    std::vector<std::vector<Line>> mem;

    int offset = 0;
    int Entery_Nums = 0; //// num of lines in set

    Level() = default;
    Level(int lSize, int blockSize, int lCycle, int wrAllocte, int ways) : L_Size(lSize), BlockSize(blockSize), L_Cycle(lCycle),
        WrAllocte(wrAllocte), ways(ways) {
        offset = blockSize; /// num of bits to offset

        if (ways == 0)
        {
            Entery_Nums = pow(2, this->L_Size - this->BlockSize);
        }
        else
        {
            Entery_Nums = pow(2, this->L_Size - this->BlockSize - ways);
        }


        for (int i = 0; i < pow(2, ways); ++i) {
            mem.push_back(std::vector<Line>());
            for (int j = 0; j < Entery_Nums; ++j) {
                mem[i].push_back(Line());
            }
        }
    }
    int FindLessUsed(unsigned int set)
    {
        int min = mem[0][set].lastCall;
        int lessed_used = 0;
        for (int i = 0; i < pow(2, this->ways); ++i) {
            //printf("mem[%d][set].LastCall=%d  (set=%d)\n", i, mem[i][set].lastCall, set);
            if (mem[i][set].lastCall < min)
            {
                lessed_used = i;
                min = mem[i][set].lastCall;  // TODO: check if this is bug fix
            }
        }
        return lessed_used;
    }

};

class Cache {
public:
    int mem_Cycle;
    int BlockSize;
    int l1_size;
    int l2_size;
    int l1_Cycle;
    int l2_Cycle;
    int l1_Assoc;
    int l2_Assoc;
    int WrAlloc;
    Level* l1;
    Level* l2;

    double accesses = 0;
    double total_time = 0;
    double l1_accesses = 0;
    double l2_accesses = 0;
    double l1_misses = 0;
    double l2_misses = 0;

    Cache(int mem_Cycle, int blockSize, int l1Size, int l2Size, int l1Cycle, int l2Cycle, int l1Assoc, int l2Assoc,
        int wrAlloc) : mem_Cycle(mem_Cycle), BlockSize(blockSize), l1_size(l1Size), l2_size(l2Size),
        l1_Cycle(l1Cycle), l2_Cycle(l2Cycle), l1_Assoc(l1Assoc), l2_Assoc(l2Assoc), WrAlloc(wrAlloc) {
        l1 = new Level(l1_size, BlockSize, l1_Cycle, WrAlloc, l1_Assoc);
        l2 = new Level(l2_size, BlockSize, l2_Cycle, WrAlloc, l2_Assoc);
    }

    virtual ~Cache() {
        delete l1;
        delete l2;
    }

    void ReadEntry(unsigned long int address, int time_cache) {
        unsigned set1 = (address >> this->BlockSize) & get_mask(log2(l1->Entery_Nums)); ///get set num
        unsigned tag1 = address >> ((int)(log2(l1->Entery_Nums)) + BlockSize);  //// get the tag

        unsigned set2 = (address >> this->BlockSize);
        set2 = set2 & get_mask(log2(l2->Entery_Nums));
        unsigned tag2 = address >> ((int)(log2(l2->Entery_Nums)) + BlockSize);

        accesses++;
        int l1_ways = pow(2, l1->ways);
        for (int i = 0; i < l1_ways; i++) {
            if (l1->mem[i][set1].tag == tag1 && l1->mem[i][set1].lastCall != 0) //L1 read hit.
            {
                //printf("L1 Hit!\n");
                l1->mem[i][set1].lastCall = time_cache;
                l1_accesses++;
                total_time += l1->L_Cycle;
                return;
            }
        }

        int l2_ways = pow(2, l2->ways);

        for (int k = 0; k < l2_ways; ++k) {
            if (l2->mem[k][set2].tag == tag2 && l2->mem[k][set2].lastCall != 0) //L1 Read miss, L2 Read hit.
            {
                //printf("L2 Hit!\n");
                l2->mem[k][set2].lastCall = time_cache;
                ///should bring from l2 to l1

                int less_used_in_l1 = this->l1->FindLessUsed(set1);
                if (this->l1->mem[less_used_in_l1][set1].dirty)
                {
                    unsigned set2_dirty_to_update = (this->l1->mem[less_used_in_l1][set1].address >> this->BlockSize) & get_mask(log2(l2->Entery_Nums));
                    unsigned tag2_dirty_to_update = this->l1->mem[less_used_in_l1][set1].address >> ((int)(l2->ways) + BlockSize);
                    /////find an update in l2
                    for (int i = 0; i < l2_ways; ++i) {
                        if (this->l2->mem[i][set2_dirty_to_update].tag == tag2_dirty_to_update)
                        {
                            time_cache++;
                            this->l2->mem[i][set2_dirty_to_update].lastCall = time_cache;
                            this->l2->mem[i][set2_dirty_to_update].dirty = true;
                        }
                    }
                    ///updates in l2
                }
                ///updates in l1
                this->l1->mem[less_used_in_l1][set1].address = address;
                this->l1->mem[less_used_in_l1][set1].tag = tag1;
                this->l1->mem[less_used_in_l1][set1].lastCall = time_cache;
                this->l1->mem[less_used_in_l1][set1].dirty = false;

                l1_accesses++;
                l2_accesses++;
                l1_misses++;
                total_time += (l1->L_Cycle + l2->L_Cycle);
                return;
            }
        }

        //L1 Read miss, L2 Read miss.
        /////we find the minimal and destroy it


        /////update l2

        /////update in l2
        int less_used_in_l2 = this->l2->FindLessUsed(set2);

        if (this->l2->mem[less_used_in_l2][set2].lastCall != 0)
        {
            unsigned set1 = (this->l2->mem[less_used_in_l2][set2].address >> this->BlockSize) & get_mask(log2(l1->Entery_Nums)); ///get set num
            unsigned tag1 = this->l2->mem[less_used_in_l2][set2].address >> ((int)(log2(l1->Entery_Nums)) + BlockSize);  //// get the tag


            for (int i = 0; i < l1_ways; ++i) {
                if (this->l1->mem[i][set1].tag == tag1)
                {
                    this->l1->mem[i][set1].lastCall = 0;
                    this->l1->mem[i][set1].dirty = false;

                }
            }
        }

        this->l2->mem[less_used_in_l2][set2].address = address;
        this->l2->mem[less_used_in_l2][set2].tag = tag2;
        this->l2->mem[less_used_in_l2][set2].lastCall = time_cache;
        this->l2->mem[less_used_in_l2][set2].dirty = false;



        /////update l1
        int less_used_in_l1 = this->l1->FindLessUsed(set1);
        if (this->l1->mem[less_used_in_l1][set1].dirty == true) {
            unsigned set2_dirty_to_update = (this->l1->mem[less_used_in_l1][set1].address >> this->BlockSize) & get_mask(log2(l2->Entery_Nums));
            unsigned tag2_dirty_to_update = this->l1->mem[less_used_in_l1][set1].address >> ((int)(log2(l2->Entery_Nums)) + BlockSize);
            /////find an update in l2
            for (int i = 0; i < l2_ways; ++i) {
                if (this->l2->mem[i][set2_dirty_to_update].tag == tag2_dirty_to_update) {
                    time_cache++;
                    this->l2->mem[i][set2_dirty_to_update].lastCall = time_cache;
                    this->l2->mem[i][set2_dirty_to_update].dirty = true;
                }
            }
        }
        this->l1->mem[less_used_in_l1][set1].address = address;
        this->l1->mem[less_used_in_l1][set1].tag = tag1;
        this->l1->mem[less_used_in_l1][set1].lastCall = time_cache;
        this->l1->mem[less_used_in_l1][set1].dirty = false;


        l1_accesses++;
        l2_accesses++;
        l1_misses++;
        l2_misses++;
        total_time += (l1->L_Cycle + l2->L_Cycle + this->mem_Cycle);
        return;
    }


    void WriteEntry(unsigned long int address, int time_cache) {
        accesses++;

        unsigned set1 = (address >> this->BlockSize) & get_mask(log2(l1->Entery_Nums)); ///get set num
        unsigned tag1 = address >> ((int)(log2(l1->Entery_Nums)) + BlockSize);  //// get the tag


        unsigned set2 = (address >> this->BlockSize) & get_mask(log2(l2->Entery_Nums));
        unsigned tag2 = address >> ((int)(log2(l2->Entery_Nums)) + BlockSize);
        if (address == 96) {
            //printf("L1 set = %d\n", set1);
            //printf("L1 tag = %d\n", tag1);
            //printf("L2 set = %d\n", set2);
            //printf("L2 tag = %d\n", tag2);
        }
        int l1_ways = pow(2, l1->ways); ///hit in l1
        for (int i = 0; i < l1_ways; i++) {
            if (address == 96) {
                //printf("Potential tag = %d\n", l1->mem[i][set1].tag);
                //printf("Potential tag lastCall? %d\n", l1->mem[i][set1].lastCall);
            }
            if (l1->mem[i][set1].tag == tag1 && l1->mem[i][set1].lastCall != 0) //L1 read hit.
            {
                //printf("L1 Hit!\n");
                l1->mem[i][set1].lastCall = time_cache;
                l1->mem[i][set1].dirty = true;
                l1_accesses++;
                total_time += l1->L_Cycle;
                return;
            }
        }


        int l2_ways = pow(2, l2->ways); // hit in l2
        for (int i = 0; i < l2_ways; i++) {
            if (l2->mem[i][set2].tag == tag2 && l2->mem[i][set2].lastCall != 0) //L2 write hit.
            {
                //printf("L2 Hit!\n");
                l2->mem[i][set2].lastCall = time_cache;
                l1_accesses++;
                l2_accesses++;
                l1_misses++;
                total_time += l2->L_Cycle + l1->L_Cycle;

                if (this->WrAlloc) {
                    l2->mem[i][set2].dirty = false;///// might be a probleme

                    int less_used_in_l1 = this->l1->FindLessUsed(set1);
                    if (this->l1->mem[less_used_in_l1][set1].lastCall != 0) {
                        unsigned set2_dirty_to_update =
                            (this->l1->mem[less_used_in_l1][set1].address >> this->BlockSize) &
                            get_mask(log2(l2->Entery_Nums));
                        unsigned tag2_dirty_to_update = this->l1->mem[less_used_in_l1][set1].address
                            >> ((int)(log2(l2->Entery_Nums)) + BlockSize);

                        /////find an update in l2
                        for (int i = 0; i < l2_ways; ++i) {
                            if (this->l2->mem[i][set2_dirty_to_update].tag == tag2_dirty_to_update) {
                                time_cache++;
                                this->l2->mem[i][set2_dirty_to_update].lastCall = time_cache;
                                this->l2->mem[i][set2_dirty_to_update].dirty = this->l1->mem[less_used_in_l1][set1].dirty;
                                break;
                            }
                        }
                    }

                    this->l1->mem[less_used_in_l1][set1].dirty = true;
                    this->l1->mem[less_used_in_l1][set1].address = address;
                    this->l1->mem[less_used_in_l1][set1].tag = tag1;
                    this->l1->mem[less_used_in_l1][set1].lastCall = time_cache;

                    return;

                }
                else {
                    l2->mem[i][set2].lastCall = time_cache;
                    l2->mem[i][set2].dirty = true;
                    return;
                }
            }
        }

        ////miss in both

        if (this->WrAlloc)
        {
            int less_used_in_l2 = this->l2->FindLessUsed(set2);

            if (this->l2->mem[less_used_in_l2][set2].lastCall != 0)
            {
                unsigned set1 = (this->l2->mem[less_used_in_l2][set2].address >> this->BlockSize) & get_mask(log2(l1->Entery_Nums)); ///get set num
                unsigned tag1 = this->l2->mem[less_used_in_l2][set2].address >> ((int)log2(l1->Entery_Nums) + BlockSize);//// get the tag

                for (int i = 0; i < l1_ways; ++i) {
                    if (this->l1->mem[i][set1].tag == tag1)
                    {
                        this->l1->mem[i][set1].lastCall = 0;
                        this->l1->mem[i][set1].dirty = false;
                        break;
                    }
                }
            }

            this->l2->mem[less_used_in_l2][set2].address = address;
            this->l2->mem[less_used_in_l2][set2].tag = tag2;
            this->l2->mem[less_used_in_l2][set2].lastCall = time_cache;
            this->l2->mem[less_used_in_l2][set2].dirty = false;



            /////update l1
            int less_used_in_l1 = this->l1->FindLessUsed(set1);
            if (this->l1->mem[less_used_in_l1][set1].lastCall != 0) {
                unsigned set2_dirty_to_update =
                    (this->l1->mem[less_used_in_l1][set1].address >> this->BlockSize) &
                    get_mask(log2(l2->Entery_Nums));
                unsigned tag2_dirty_to_update = this->l1->mem[less_used_in_l1][set1].address
                    >> ((int)(log2(l2->Entery_Nums)) + BlockSize);

                /////find an update in l2
                for (int i = 0; i < l2_ways; ++i) {
                    if (this->l2->mem[i][set2_dirty_to_update].tag == tag2_dirty_to_update) {
                        time_cache++;
                        this->l2->mem[i][set2_dirty_to_update].lastCall = time_cache;
                        this->l2->mem[i][set2_dirty_to_update].dirty = this->l1->mem[less_used_in_l1][set1].dirty;
                        break;
                    }
                }
            }

            this->l1->mem[less_used_in_l1][set1].dirty = true;
            this->l1->mem[less_used_in_l1][set1].address = address;
            this->l1->mem[less_used_in_l1][set1].tag = tag1;
            this->l1->mem[less_used_in_l1][set1].lastCall = time_cache;
        }

        l1_accesses++;
        l2_accesses++;
        l1_misses++;
        l2_misses++;
        total_time += (l1->L_Cycle + l2->L_Cycle + this->mem_Cycle);
    }
};

using std::FILE;
using std::string;
using std::cout;
using std::endl;
using std::cerr;
using std::ifstream;
using std::stringstream;

int main(int argc, char** argv) {

    if (argc < 19) {
        cerr << "Not enough arguments" << endl;
        return 0;
    }

    // Get input arguments

    // File
    // Assuming it is the first argument
    char* fileString = argv[1];
    ifstream file(fileString); //input file stream
    string line;
    if (!file || !file.good()) {
        // File doesn't exist or some other error
        cerr << "File not found" << endl;
        return 0;
    }

    unsigned MemCyc = 0, BSize = 0, L1Size = 0, L2Size = 0, L1Assoc = 0,
        L2Assoc = 0, L1Cyc = 0, L2Cyc = 0, WrAlloc = 0;

    for (int i = 2; i < 19; i += 2) {
        string s(argv[i]);
        if (s == "--mem-cyc") {
            MemCyc = atoi(argv[i + 1]);
        }
        else if (s == "--bsize") {
            BSize = atoi(argv[i + 1]);
        }
        else if (s == "--l1-size") {
            L1Size = atoi(argv[i + 1]);
        }
        else if (s == "--l2-size") {
            L2Size = atoi(argv[i + 1]);
        }
        else if (s == "--l1-cyc") {
            L1Cyc = atoi(argv[i + 1]);
        }
        else if (s == "--l2-cyc") {
            L2Cyc = atoi(argv[i + 1]);
        }
        else if (s == "--l1-assoc") {
            L1Assoc = atoi(argv[i + 1]);
        }
        else if (s == "--l2-assoc") {
            L2Assoc = atoi(argv[i + 1]);
        }
        else if (s == "--wr-alloc") {
            WrAlloc = atoi(argv[i + 1]);
        }
        else {
            cerr << "Error in arguments" << endl;
            return 0;
        }
    }

    /////cache init
    Cache* OurCache = new Cache(MemCyc, BSize, L1Size, L2Size, L1Cyc, L2Cyc, L1Assoc, L2Assoc, WrAlloc);
    int counter = 0;
    while (getline(file, line)) {
        //printf("%d \n", counter);
        stringstream ss(line);
        string address;
        char operation = 0; // read (R) or write (W)
        if (!(ss >> operation >> address)) {
            // Operation appears in an Invalid format
            cout << "Command Format error" << endl;
            return 0;
        }

        string cutAddress = address.substr(2); // Removing the "0x" part of the address


        unsigned long int num = 0;
        num = strtoul(cutAddress.c_str(), NULL, 16);

        //////////////do the opration
        if (operation == 'r')
        {
            OurCache->ReadEntry(num, time_cache);
            time_cache++;
        }
        if (operation == 'w')
        {
            OurCache->WriteEntry(num, time_cache);
            time_cache++;
        }
        counter++;
    }

    double L1MissRate;
    double L2MissRate;
    double avgAccTime;

    L1MissRate = (OurCache->l1_misses) / (OurCache->l1_accesses);
    L2MissRate = (OurCache->l2_misses) / (OurCache->l2_accesses);
    avgAccTime = (OurCache->total_time) / (OurCache->accesses);

    printf("L1miss=%.03f ", L1MissRate);
    printf("L2miss=%.03f ", L2MissRate);
    printf("AccTimeAvg=%.03f\n", avgAccTime);

    return 0;
}

/* 046267 Computer Architecture - Winter 20/21 - HW #4 */

#include "core_api.h"
#include "sim_api.h"
#include <vector>

class Core {
public:
    int numThread;
    int currThread;
    int numCycles;
    int numInst;
    bool idle;
    std::vector<int> untillUsable;
    std::vector<tcontext> threadRegs;
    std::vector<int> instCount;
    std::vector<bool> finishedThreads;


    Core() : currThread(0), numCycles(0), numInst(0), idle(false) {
        numThread = SIM_GetThreadsNum();
        finishedThreads = std::vector<bool>(numThread, false);
        instCount = std::vector<int>(numThread, 0);
        threadRegs = std::vector<tcontext>(numThread);
        untillUsable = std::vector<int>(numThread, 0);
        for(int i=0; i<numThread; i++) {
            for(int j=0; j<REGS_COUNT; j++) {
                threadRegs[i].reg[j] = 0;
            }
        }

    }
    ~Core() = default;

    void executeInst(Instruction inst,int currThread_running) {
        cmd_opcode tmp = inst.opcode;
        if(tmp == CMD_HALT) {
            return;
        } else if(tmp == CMD_ADD) {
            threadRegs[currThread_running].reg[inst.dst_index] = threadRegs[currThread_running].reg[inst.src1_index] + threadRegs[currThread_running].reg[inst.src2_index_imm];
        } else if(tmp == CMD_SUB) {
            threadRegs[currThread_running].reg[inst.dst_index] = threadRegs[currThread_running].reg[inst.src1_index] - threadRegs[currThread_running].reg[inst.src2_index_imm];
        } else if(tmp == CMD_ADDI) {
            threadRegs[currThread_running].reg[inst.dst_index] = threadRegs[currThread_running].reg[inst.src1_index] + inst.src2_index_imm;
        } else if(tmp == CMD_SUBI) {
            threadRegs[currThread_running].reg[inst.dst_index] = threadRegs[currThread_running].reg[inst.src1_index] - inst.src2_index_imm;
        } else if(tmp == CMD_LOAD) {
            int32_t dst = inst.dst_index;
            uint32_t address = 0;
            if(!inst.isSrc2Imm) {
                address += threadRegs[currThread_running].reg[inst.src2_index_imm];
            } else {
                address += inst.src2_index_imm;
            }
            address += threadRegs[currThread_running].reg[inst.src1_index];
            SIM_MemDataRead(address, &threadRegs[currThread_running].reg[dst]);
            untillUsable[currThread_running] += SIM_GetLoadLat() + 1;
            idle = true;
        } else if(tmp == CMD_STORE) {
            int32_t val = threadRegs[currThread_running].reg[inst.src1_index];
            uint32_t address = threadRegs[currThread_running].reg[inst.dst_index];
            if(!inst.isSrc2Imm) {
                address += threadRegs[currThread_running].reg[inst.src2_index_imm];
            } else {
                address += inst.src2_index_imm;
            }
            untillUsable[currThread_running] += SIM_GetStoreLat() + 1;
            SIM_MemDataWrite(address, val);
            idle = true;
        }
        if(tmp != CMD_HALT) {
            instCount[currThread_running]++;
        }
    }

    void updateUntillUsable()
    {
        for (int i = 0; i < numThread; ++i) {
            if (untillUsable[i]>0 && !finishedThreads[i]) /// comeback
            {
                untillUsable[i]--;
            }
        }
    }

    bool checkIdle(int curr)
    {
        for (int i = curr; i < this->numThread+curr; ++i) {
            if (!finishedThreads[i%numThread] && untillUsable[i%numThread] == 0) {
                return false;
            }
        }
        return true;
    }

    void executeCore_blocked() {
        int haltCount = 0;
        Instruction currInst;
        int running_thread = 0;
        while (haltCount != numThread) {
            if (!idle) {
                SIM_MemInstRead(instCount[running_thread], &currInst, running_thread);
                executeInst(currInst, running_thread);
                numCycles++;
                if (currInst.opcode == CMD_HALT) {
                    haltCount++;
                    finishedThreads[running_thread] = true;
                    if (haltCount == numThread) break;
                }
            }
            updateUntillUsable();///update

            while (checkIdle(running_thread)) {
                numCycles++;
                updateUntillUsable();
            }
            idle=checkIdle(running_thread);

            int original = running_thread;///chose next

            for (int i = running_thread; i < this->numThread+running_thread; ++i) {
                if (!finishedThreads[(i)%numThread] && untillUsable[(i)%numThread] == 0) {
                    running_thread = (i)%numThread;
                    break;
                }
            }

            if (original != running_thread) {
                int tmp = SIM_GetSwitchCycles();
                while (tmp > 0) {
                    numCycles++;
                    updateUntillUsable();
                    tmp--;
                }
            }
        }
        int sum = 0;
        for(int i=0; i<numThread; i++) {
            sum+=instCount[i];
        }
        numInst += numThread;
        numInst += sum;
    }


    void executeCoreFairGain() {
        int haltCount = 0;
        Instruction currInst;
        int running_thread = 0;
        while (haltCount != numThread) {
            if (!idle) {
                SIM_MemInstRead(instCount[running_thread], &currInst, running_thread);
                executeInst(currInst, running_thread);
                numCycles++;
                if (currInst.opcode == CMD_HALT) {
                    haltCount++;
                    finishedThreads[running_thread] = true;
                }
            }
            if (haltCount == numThread) break;



            updateUntillUsable();///update

            while ((idle = checkIdle(running_thread))) {
                numCycles++;
                updateUntillUsable();
            }

            for (int i = running_thread+1; i < this->numThread + running_thread; ++i) {
                if (!finishedThreads[(i) % numThread] && untillUsable[(i) % numThread] == 0) {
                    running_thread = (i) % numThread;
                    break;
                }
            }
        }
        int sum = 0;
        for(int i=0; i<numThread; i++) {
            sum+=instCount[i];
        }
        numInst += numThread;
        numInst += sum;
    }
};

Core *BlockedMT = nullptr;
Core *FineGrainedMT = nullptr;

void CORE_BlockedMT() {
    BlockedMT = new Core();
    BlockedMT->executeCore_blocked();
}

void CORE_FinegrainedMT() {
    FineGrainedMT = new Core();
    FineGrainedMT->executeCoreFairGain();
}

void CORE_BlockedMT_CTX(tcontext* context, int threadId) {
    if(context == nullptr) return;
    if(threadId >= BlockedMT->numThread  || threadId < 0) return;
    for(int i=0; i<REGS_COUNT; i++) {
        context[threadId].reg[i] = BlockedMT->threadRegs[threadId].reg[i];
    }
}

double CORE_BlockedMT_CPI(){
    return (double) (BlockedMT->numCycles)/(BlockedMT->numInst);
}

double CORE_FinegrainedMT_CPI(){
    return (double) (FineGrainedMT->numCycles)/(FineGrainedMT->numInst);
}

void CORE_FinegrainedMT_CTX(tcontext* context, int threadid) {
    if(context == nullptr) return;
    if(threadid >= BlockedMT->numThread  || threadid < 0) return;
    for(int i=0; i<REGS_COUNT; i++) {
        context[threadid].reg[i] = FineGrainedMT->threadRegs[threadid].reg[i];
    }
}
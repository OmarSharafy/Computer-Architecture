//
// Created by HP-WIN10 on 02/01/2023.
//

#include "dflow_calc.h"
#include "vector"
#include "iostream"
#include "cmath"

class Instrction{
public:
  unsigned int Op;
  unsigned int surce1;
  unsigned int sorce2;
  unsigned int dist;
  bool isDependedOnDist1= false;
  bool isDependedOnDist2= false;
  bool pointed= false; ////is someone in need of me ?
  bool pointed_by_exit= false;
    std::vector<int> dependedOnVec; /// what i depened on
  unsigned int TotalTime=0;
  bool first_surce= false;
  bool sec_surce= false;

    Instrction() : Op(-2), surce1(0),
               sorce2(0), dist(0){};


    virtual ~Instrction() = default;
};

class Graph{
public:
    std::vector<Instrction> track;
    unsigned int numOfInst;
    unsigned int opsLatency [MAX_OPS];

    explicit Graph(unsigned int numOfInst) : track(numOfInst+1), numOfInst(numOfInst){};

    virtual ~Graph() = default;
};

ProgCtx analyzeProg(const unsigned int opsLatency[], const InstInfo progTrace[], unsigned int numOfInsts){
    Graph *OurGraph = new Graph(numOfInsts);
    if(OurGraph == nullptr) //check allocation failure.
    {
        return PROG_CTX_NULL;
    }
    for (int i =0; i < MAX_OPS; ++i) {
        OurGraph->opsLatency[i]=opsLatency[i];
    }

    for (unsigned int i = 0; i < numOfInsts; ++i) {
        OurGraph->track[i].dependedOnVec.push_back(-1);
        OurGraph->track[i].dependedOnVec.push_back(-1);
        OurGraph->track[i].Op=progTrace[i].opcode;
        OurGraph->track[i].surce1=progTrace[i].src1Idx;
        OurGraph->track[i].sorce2=progTrace[i].src2Idx;
        OurGraph->track[i].dist=progTrace[i].dstIdx;
    //    OurGraph->track[i].time=opsLatency[i];
    }

    for ( unsigned int i = 0; i < numOfInsts; ++i){ ///check if i depeneds on someone

        for ( int j = i-1; j >=0 ; --j) {

           unsigned int dest = OurGraph->track[j].dist; ////check RAW and WAW


           if (OurGraph->track[i].isDependedOnDist1 && OurGraph->track[i].isDependedOnDist2)
           {
               break;
           }

           if (OurGraph->track[i].surce1 == dest && !OurGraph->track[i].isDependedOnDist1)
           {
               OurGraph->track[i].isDependedOnDist1= true;
               OurGraph->track[i].dependedOnVec[0]=j;
               OurGraph->track[j].pointed= true; // j is not the end of this track
               OurGraph->track[j].first_surce= true;
           }
           if (OurGraph->track[i].sorce2 == dest && !OurGraph->track[i].isDependedOnDist2)
           {
               OurGraph->track[i].isDependedOnDist2= true;
               OurGraph->track[i].dependedOnVec[1]=j;
               OurGraph->track[j].pointed= true; // j is not the end of this track
               OurGraph->track[j].sec_surce= true;

           }

        }
    }


    for (unsigned int i = 0; i < OurGraph->numOfInst; i++) // Compute the Depths of each intsruction and the one that depends on him.
    {

        for (auto dep : OurGraph->track[i].dependedOnVec)
        {
            if(dep==-1)
            {
                continue;
            }
            unsigned int latency = OurGraph->opsLatency[OurGraph->track[dep].Op];
            if (OurGraph->track[i].TotalTime<OurGraph->track[dep].TotalTime + latency) {
                OurGraph->track[i].TotalTime = OurGraph->track[dep].TotalTime + latency;
            }
        }
    }

    for (unsigned int i = 0; i < numOfInsts; ++i) {
        if (!OurGraph->track[i].pointed)
        {
            OurGraph->track[i].pointed_by_exit= true;
        }
    }

    return OurGraph;
}


int getInstDepth(ProgCtx ctx, unsigned int theInst) {
    auto* prog = (Graph*)ctx;

    return prog->track[theInst].TotalTime;

}

int getInstDeps(ProgCtx ctx, unsigned int theInst, int *src1DepInst, int *src2DepInst) {

    auto* prog = (Graph*)ctx;
    if(theInst < 0 || theInst >= prog->numOfInst) // input validation
    {
        return -1;
    }


     if (prog->track[theInst].dependedOnVec.empty())
     {
         *src1DepInst =-1;
         *src2DepInst = -1;
         return 0;
     }
     else if (prog->track[theInst].dependedOnVec.size()==1)
     {
         if (prog->track[theInst].isDependedOnDist1) {
             *src1DepInst =prog->track[theInst].dependedOnVec[0];
             *src2DepInst = prog->track[theInst].dependedOnVec[1];
         }
         else
         {
             *src1DepInst =prog->track[theInst].dependedOnVec[0];
             *src2DepInst = prog->track[theInst].dependedOnVec[1];
         }
         return 0;
     }
     else {
         *src1DepInst =prog->track[theInst].dependedOnVec[0];
         *src2DepInst = prog->track[theInst].dependedOnVec[1];
         return 0;
     }
}


void freeProgCtx(ProgCtx ctx)
{
    Graph* prog = (Graph*)ctx;
    delete prog;
}

int getProgDepth(ProgCtx ctx) {
    Graph* prog = (Graph*)ctx;
    int time=0;
    for (unsigned int i = 0; i < prog->numOfInst; ++i) {
        int latency = prog->opsLatency[prog->track[i].Op];
        if (prog->track[i].pointed_by_exit)
        {
            time = std::max(time ,getInstDepth(ctx,i) + latency);
        }
    }
    return time;
}